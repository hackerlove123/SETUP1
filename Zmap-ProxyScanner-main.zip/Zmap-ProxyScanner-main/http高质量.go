/*
	code by 黑客情报局 https://t.me/HackerBankBTC
*/

package main

import (
	"fmt"
	"h12.io/socks"
	"log"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// 定义代理结构体
type Proxy struct {
	ips                  map[string]struct{}
	targetSites          []string
	httpStatusValidation bool
	timeout              time.Duration
	maxHttpThreads       int64

	openHttpThreads int64
	mu              sync.Mutex
}

// 创建全局代理变量
var Proxies = &Proxy{
	// in work
	targetSites: []string{"https://google.com", "https://cloudflare.com"},

	httpStatusValidation: false,
	// now cfg file
	timeout:        time.Second * 5,
	maxHttpThreads: int64(config.HttpThreads),
	ips:            make(map[string]struct{}),
}

// WorkerThread 函数负责从队列中获取代理并进行验证
func (p *Proxy) WorkerThread() {
	for {
		for atomic.LoadInt64(&p.openHttpThreads) < int64(config.HttpThreads) {
			p.mu.Lock()
			for proxy, _ := range p.ips {
                // 根据配置的代理类型，调用不同的验证函数
				if strings.ToLower(config.ProxyType) == "http" { 
					go p.CheckProxyHTTP(proxy)
				} else if strings.ToLower(config.ProxyType) == "socks4" {
					go p.CheckProxySocks4(proxy)
				} else if strings.ToLower(config.ProxyType) == "socks5" {
					go p.CheckProxySocks5(proxy)
				} else {
					log.Fatalln("invalid ProxyType") 
				}
				delete(p.ips, proxy)
				break
			}
			p.mu.Unlock()

		}
		time.Sleep(time.Millisecond * 100) 
	}
}

// CheckProxyHTTP 函数用于验证 HTTP 代理
func (p *Proxy) CheckProxyHTTP(proxy string) {
	atomic.AddInt64(&p.openHttpThreads, 1)
	defer func() {
		atomic.AddInt64(&p.openHttpThreads, -1)
		atomic.AddUint64(&checked, 1)
	}()

	var err error
	s := strings.Split(proxy, ":")
	if len(s) <= 1 {
		log.Println("invalid proxy format:", proxy)
		return
	}

	proxyPort, err := strconv.Atoi(strings.TrimSpace(s[1]))
	if err != nil {
		log.Println(err)
		return
	}

	proxyUrl, err := url.Parse(fmt.Sprintf("http://%s:%d", s[0], proxyPort))
	if err != nil {
		log.Println(err)
		return
	}

    // 使用代理创建一个 HTTP Transport
	tr := &http.Transport{
		Proxy: http.ProxyURL(proxyUrl),
		DialContext: (&net.Dialer{
			Timeout:   time.Second * time.Duration(config.Timeout.HttpTimeout),
			KeepAlive: time.Second,
			DualStack: true,
		}).DialContext,
	}

    // 创建一个 HTTP Client
	client := http.Client{
		Timeout:   time.Second * time.Duration(config.Timeout.HttpTimeout),
		Transport: tr,
	}

    // 创建一个 HTTP 请求
	req, err := http.NewRequest("GET", config.CheckSite, nil) 
	if err != nil {
		log.Fatalln(err)
	}
	req.Header.Add("User-Agent", config.Headers.UserAgent)
	req.Header.Add("accept", config.Headers.Accept)
	req.Header.Add("X-Proxy-Checker", "Test") // 添加自定义请求头

	res, err := client.Do(req) // 发送请求
	if err != nil {
		atomic.AddUint64(&proxyErr, 1)
		if strings.Contains(err.Error(), "timeout") {
			atomic.AddUint64(&timeoutErr, 1)
			return
		}
		return
	}
	res.Body.Close()

    // 检查自定义请求头是否存在于响应头中
	if res.Header.Get("X-Proxy-Checker") == "Test" {
		if config.PrintIps.Enabled {
			go PrintProxy(s[0], proxyPort)
		}
		atomic.AddUint64(&success, 1)
		exporter.Add(fmt.Sprintf("%s:%d", s[0], proxyPort))
	} else {
		// 代理服务器没有正确转发请求
		atomic.AddUint64(&proxyErr, 1)
	}
}

// CheckProxySocks4 函数用于验证 SOCKS4 代理
func (p *Proxy) CheckProxySocks4(proxy string) {
	atomic.AddInt64(&p.openHttpThreads, 1)
	defer func() {
		atomic.AddInt64(&p.openHttpThreads, -1)
		atomic.AddUint64(&checked, 1)
	}()

	var err error
	s := strings.Split(proxy, ":")
	if len(s) <= 1 {
		log.Println("invalid proxy format:", proxy)
		return
	}

	proxyPort, err := strconv.Atoi(strings.TrimSpace(s[1]))
	if err != nil {
		log.Println(err)
		return
	}

    // 使用 socks4 协议进行连接
	tr := &http.Transport{
		Dial: socks.Dial(fmt.Sprintf("socks4://%s:%d?timeout=%ds", s[0], proxyPort, config.Timeout.Socks4Timeout)), 
	}

    // 创建一个 HTTP Client
	client := http.Client{
		Timeout:   time.Second * time.Duration(config.Timeout.HttpTimeout),
		Transport: tr,
	}

    // 创建一个 HTTP 请求
	req, err := http.NewRequest("GET", config.CheckSite, nil) 
	if err != nil {
		log.Fatalln(err)
	}
	req.Header.Add("User-Agent", config.Headers.UserAgent)
	req.Header.Add("accept", config.Headers.Accept)
	req.Header.Add("X-Proxy-Checker", "Test") // 添加自定义请求头

	res, err := client.Do(req) // 发送请求
	if err != nil {
		atomic.AddUint64(&proxyErr, 1)
		if strings.Contains(err.Error(), "timeout") {
			atomic.AddUint64(&timeoutErr, 1)
			return
		}
		return
	}
	res.Body.Close()

    // 检查自定义请求头是否存在于响应头中
	if res.Header.Get("X-Proxy-Checker") == "Test" {
		if config.PrintIps.Enabled {
			go PrintProxy(s[0], proxyPort)
		}
		atomic.AddUint64(&success, 1)
		exporter.Add(fmt.Sprintf("%s:%d", s[0], proxyPort))
	} else {
		// 代理服务器没有正确转发请求
		atomic.AddUint64(&proxyErr, 1)
	}
}

// CheckProxySocks5 函数用于验证 SOCKS5 代理
func (p *Proxy) CheckProxySocks5(proxy string) {
	atomic.AddInt64(&p.openHttpThreads, 1)
	defer func() {
		atomic.AddInt64(&p.openHttpThreads, -1)
		atomic.AddUint64(&checked, 1)
	}()

	var err error
	s := strings.Split(proxy, ":")
	if len(s) <= 1 {
		log.Println("invalid proxy format:", proxy)
		return
	}

	proxyPort, err := strconv.Atoi(strings.TrimSpace(s[1]))
	if err != nil {
		log.Println(err)
		return
	}

    // 使用 socks5 协议进行连接
	tr := &http.Transport{
		Dial: socks.Dial(fmt.Sprintf("socks5://%s:%d?timeout=%ds", s[0], proxyPort, config.Timeout.Socks5Timeout)),
	}

    // 创建一个 HTTP Client
	client := http.Client{
		Timeout:   time.Second * time.Duration(config.Timeout.HttpTimeout),
		Transport: tr,
	}

    // 创建一个 HTTP 请求
	req, err := http.NewRequest("GET", config.CheckSite, nil)
	if err != nil {
		log.Fatalln(err)
	}
	req.Header.Add("User-Agent", config.Headers.UserAgent)
	req.Header.Add("accept", config.Headers.Accept)
	req.Header.Add("X-Proxy-Checker", "Test") // 添加自定义请求头

	res, err := client.Do(req) // 发送请求
	if err != nil {
		atomic.AddUint64(&proxyErr, 1)
		if strings.Contains(err.Error(), "timeout") {
			atomic.AddUint64(&timeoutErr, 1)
			return
		}
		return
	}
	res.Body.Close()

    // 检查自定义请求头是否存在于响应头中
	if res.Header.Get("X-Proxy-Checker") == "Test" {
		if config.PrintIps.Enabled {
			go PrintProxy(s[0], proxyPort)
		}
		atomic.AddUint64(&success, 1)
		exporter.Add(fmt.Sprintf("%s:%d", s[0], proxyPort))
	} else {
		// 代理服务器没有正确转发请求
		atomic.AddUint64(&proxyErr, 1)
	}
}