/*
	(c) Yariya
*/

package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"regexp"
)

// func Scanner() {
func Scanner(ports []string) {
	if *fetch != "" {
		log.Printf("Detected URL Mode.\n")
		res, err := http.Get(*fetch)
		if err != nil {
			log.Fatalln("fetch error")
		}
		body, err := io.ReadAll(res.Body)
		if err != nil {
			log.Fatalln("fetch body error")
		}
		res.Body.Close()

		scanner := bufio.NewScanner(bytes.NewReader(body))
		// for scanner.Scan() {
		// 	ip := scanner.Text()
		// 	queueChan <- ip
		// }
		for scanner.Scan() {
			ip := scanner.Text()
			for _, port := range ports { // 遍历端口号列表
				queueChan <- fmt.Sprintf("%s:%s", ip, port) // 组合 IP 地址和端口号
			}
		}
	} else if *input != "" {
		fmt.Printf("Detected FILE Mode.\n")
		b, err := os.ReadFile(*input)
		if err != nil {
			log.Fatalln("open file err")
		}
		lines := strings.Split(string(b), "\n")
		for _, line := range lines {
			queueChan <- line
		}
	} else {
        fmt.Printf("Detected ZMAP Mode.\n")
        scanner := bufio.NewScanner(os.Stdin)

        var re *regexp.Regexp // 定义一个正则表达式变量

        if len(ports) == 1 {  // 如果只扫描单个端口
            re = regexp.MustCompile(`([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})`) // 只匹配 IP 地址
        } else {             // 如果扫描多个端口
            re = regexp.MustCompile(`([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}),([0-9]+)`) // 匹配 "IP地址,端口号"
        }

        for scanner.Scan() {
            line := scanner.Text()
            matches := re.FindStringSubmatch(line)
            
            // 根据匹配结果判断是单端口还是多端口模式
            if len(matches) == 2 { // 单端口模式，matches[1] 是 IP 地址
                ip := matches[1]
                for _, port := range ports {
                    queueChan <- fmt.Sprintf("%s:%s", ip, port)
                }
            } else if len(matches) == 3 { // 多端口模式，matches[1] 是 IP 地址，matches[2] 是端口号
                ip := matches[1]
                port := matches[2]
                queueChan <- fmt.Sprintf("%s:%s", ip, port)
            } else {
                log.Println("Invalid Zmap output format:", line)
            }
        }
    }
}
