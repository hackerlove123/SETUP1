zmap -w ipss.txt -p 3128,80,443,8080,8081,999,8010,1080,8888 --bandwidth=1000M | ./ZmapProxyScanner -p 3128,80,443,8080,8081,999,8010,1080,8888 -type http -save http.txt
