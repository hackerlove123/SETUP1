zmap -p 80 --bandwidth=1000M | ./ZmapProxyScanner -p 80 -type mix -save proxies.txt
